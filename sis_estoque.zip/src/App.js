import Header from './layouts/Header';

function App() {
  return (
    <div className="App">
      <Header />
    </div>
  );
}

export default App;
